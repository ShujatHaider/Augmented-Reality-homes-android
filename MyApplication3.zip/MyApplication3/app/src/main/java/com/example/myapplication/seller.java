package com.example.myapplication;

import android.app.DatePickerDialog;
import android.app.Fragment;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Spinner;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Calendar;

public class seller extends Fragment {

    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.seller,container,false);

    }

    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    EditText name,phone,account;
    Button button;
    record customer;
    Button btnLocation;

    @Override
    public void onActivityCreated(@Nullable final Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        sharedPreferences = getActivity().getApplicationContext().getSharedPreferences("data", 0);
        name=getActivity().findViewById(R.id.name1);
        phone=getActivity().findViewById(R.id.phone1);
        account=getActivity().findViewById(R.id.account1);
        button=getActivity().findViewById(R.id.submit1);
        FirebaseDatabase database = FirebaseDatabase.getInstance();
        btnLocation=getView().findViewById(R.id.btnlocation);
        btnLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getActivity().getApplicationContext(),sellerlocation.class);
                startActivity(intent);
            }
        });
        final DatabaseReference myRef = database.getReference().child("records");
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int cust=0;
                customer=new record(name.getText().toString(),phone.getText().toString(),account.getText().toString());
                cust=sharedPreferences.getInt("cust",0)+1;
                editor=sharedPreferences.edit();
                editor.putInt("cust",cust);
                editor.putInt("check",1);
                editor.apply();
                myRef.push().setValue(customer);
// Write a message to the database

            }
        });
    }

}
