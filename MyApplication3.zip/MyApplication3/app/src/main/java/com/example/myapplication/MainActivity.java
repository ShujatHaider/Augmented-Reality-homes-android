package com.example.myapplication;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
//import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity {

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction,fragmentTransaction1;
    Button btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseDatabase database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = database.getReference("message");

        myRef.setValue("Hello, World!");
        
        btn1=findViewById(R.id.btn1);
        btn2=findViewById(R.id.btn2);
        //fragmentManager=getFragmentManager();
        //fragmentTransaction1=fragmentManager.beginTransaction();
        //fragmentTransaction1.replace(R.id.frame,new menu());
        //fragmentTransaction1.commit();
        btn1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
//Fragment fr=new buyer();
                btn1.setVisibility(View.INVISIBLE);
                btn2.setVisibility(View.INVISIBLE);
                fragmentManager=getFragmentManager();
                fragmentTransaction=fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame,new buyer());
                fragmentTransaction.commit();
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                btn1.setVisibility(View.INVISIBLE);
                btn2.setVisibility(View.INVISIBLE);
                fragmentManager=getFragmentManager();
                fragmentTransaction=fragmentManager.beginTransaction();
                fragmentTransaction.replace(R.id.frame,new seller());
                fragmentTransaction.commit();
            }
        });
    }

}
