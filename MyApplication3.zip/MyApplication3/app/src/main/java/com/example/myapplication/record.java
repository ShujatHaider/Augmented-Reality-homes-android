package com.example.myapplication;

public class record {
    String name;
    String phone;
    String account;
    protected
    record()
    {}
    record(String name,String phone,String account)
    {
        this.name=name;
        this.account=account;
        this.phone=phone;
    }

    public void setAccount(String account) {
        this.account = account;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAccount() {
        return account;
    }

    public String getPhone() {
        return phone;
    }

    public String getName() {
        return name;
    }

}
